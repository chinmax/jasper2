package robotics;

import ch.aplu.robotsim.*;

public class SquareUsingLoop {

    public SquareUsingLoop() {
        NxtRobot robot = new NxtRobot();
        Gear gear = new Gear();
        robot.addPart(gear);
        for (int j = 1; j <= 4; j++) {
            gear.forward(2000);
            gear.right(600);
        }
        int i = 1;
        while (i <= 4) {
            gear.forward(2000);
            gear.left(600);
            i++;
        }
    }

    public static void main(String[] args) {
        new SquareUsingLoop();
    }
}
