package robotics;

import ch.aplu.robotsim.*;

public class MoveWithMotors {

    public MoveWithMotors() {
        NxtRobot robot = new NxtRobot();
        Motor motorA = new Motor(MotorPort.A);
        Motor motorB = new Motor(MotorPort.B);
        robot.addPart(motorA);
        robot.addPart(motorB);
        motorA.forward();
        motorB.forward();
        Tools.delay(2000);
        motorA.stop();
        Tools.delay(1050);
        motorA.forward();
        Tools.delay(2000);
        motorB.stop();
        Tools.delay(1050);
        motorB.forward();
        Tools.delay(2000);
        robot.exit();
    }

    public static void main(String[] args) {
        new MoveWithMotors();
    }
}
