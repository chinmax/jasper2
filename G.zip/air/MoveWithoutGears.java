package robotics;

import ch.aplu.robotsim.*;

class MoveWithoutGears {

    MoveWithoutGears() {
        TurtleRobot robot = new TurtleRobot();
        robot.forward(50);
        robot.left(90);
        robot.forward(75);
        robot.right(150);
        robot.forward(50);
        robot.exit();
    }

    public static void main(String[] args) {
        new MoveWithoutGears();
    }
}
