package robotics;

import ch.aplu.robotsim.*;

class MoveWithGear {

    MoveWithGear() {
        NxtRobot robot = new NxtRobot();
        Gear gear = new Gear();
        robot.addPart(gear);
        gear.forward(2000);
        gear.setSpeed(40);
        gear.right(600);
        gear.forward(2000);
        gear.left(1200);
        gear.forward(2000);
        robot.exit();
    }

    public static void main(String[] args) {
        new MoveWithGear();
    }
}
