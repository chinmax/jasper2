package robotics;

import ch.aplu.robotsim.*;

class CircleTwoMotors {

    CircleTwoMotors() {
        NxtRobot robot = new NxtRobot();
        Gear gear = new Gear();
        robot.addPart(gear);
        gear.setSpeed(65);
        gear.leftArc(0.25, 7000);
        gear.rightArc(0.25, 7000);
        robot.exit();
    }

    public static void main(String[] args) {
        new CircleTwoMotors();
    }
}
