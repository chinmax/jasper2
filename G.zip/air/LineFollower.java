package robotics;

import ch.aplu.robotsim.*;

class LineFollower {

    LineFollower() {
        LegoRobot robot = new LegoRobot();
        Gear gear = new Gear();
        LightSensor ls = new LightSensor(SensorPort.S3); // S3: middle port
        robot.addPart(gear);
        robot.addPart(ls);
        gear.setSpeed(30);
        while (true) {
            int v = ls.getValue();
            if (v < 100) // black
            {
                gear.forward();
            }
            if (v > 300 && v < 750) // blue
            {
                gear.leftArc(0.075);
            }
            if (v > 750) // yellow
            {
                gear.rightArc(0.075);
            }
        }
    }

    public static void main(String[] args) {
        new LineFollower();
    }

    static {
        RobotContext.setStartPosition(50, 490);
        RobotContext.setStartDirection(270);
        RobotContext.useBackground("sprites/road.gif");
    }
}
