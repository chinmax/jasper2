package ai;

import java.util.*;
import java.io.*;

public class BFS {

    ArrayList arr = new ArrayList();
    String str[] = new String[2];
    String path[] = new String[20];
    int i, j, k = 0;

    public BFS() {
//Adding Name Of City To The Arraylist.
        arr.add("Arad");
        arr.add("Zerind");
        arr.add("Sibiu");
        arr.add("Timisoara");
        arr.add("Rimnicu Vilcea");
        arr.add("Fagaras");
        arr.add("Lugoj");
        arr.add("Craiova");
        arr.add("Pitesti");
        arr.add("Bucharest");
        arr.add("Mehadia");
        arr.add("Dobreta");
        arr.add("Pitesti");
        arr.add("Bucharest");
        arr.add("Dobreta");
    }

    public void breadth() {
        if (arr.isEmpty()) {
            System.out.println("Empty");
        }
        for (i = 0; i < 20; i++) {
            path[i] = "";
        }
        str[0] = "";
        str[1] = "";
//Representing Cities in the tree format.
        System.out.println("\t\t\tArad\n");
        System.out.println("Zerind\t\t\tSibiu\t\t\tTimisoara\n");
        System.out.println("\t\tRimnicu Vilcea Fagaras\tLugoj\n");
        System.out.println("\t\tCraiova Pitesti Bucharest\t Mehadia\n");
        System.out.println("\tDobreta Pitesti Bucharest\t\tDobreta\n");
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter the initial node from the above tree: ");
            str[0] = br.readLine();
            System.out.print("Enter the goal node: ");
            str[1] = br.readLine();
//To Find The Goal.
            if (arr.contains(str[1])) {
                System.out.println("\nGoal is found\n");
//To Store the Entire Path from initial node to goal.
                for (j = arr.indexOf(str[0]); j <= arr.indexOf(str[1]); j++) {
                    path[k] = arr.get(j).toString();
                    k++;
                }
            }
        } catch (IOException e) {
        }
        System.out.println("Path is -");
        for (j = 0; j < k; j++) {
            System.out.print(path[j]);
            if (j != k - 1) {
                System.out.print(" > ");
            }
        }
        System.out.println("");
    }

    public static void main(String arg[]) {
        BFS b = new BFS();
        b.breadth();
    }
}
